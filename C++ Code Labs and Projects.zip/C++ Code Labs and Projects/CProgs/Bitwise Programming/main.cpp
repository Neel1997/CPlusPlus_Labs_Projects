/****************************************************************************
* Optional Programming Lab for Digital Logic Design
*
* Programmer: Neel Patel
*
* Submission Date: April 25, 2018
*
* EGRE 254 Spring 2018
*
* Pledge: I have neither given nor received unauthorized aid on the program.
*
* Description: Bitwise Programming Lab 
*
*
***************************************************************************/
#include <iostream>
#include <bitset>
#include <cstdlib>

using namespace std;

char reverse(char);
float negate(float);

int main() {
	char input;
	
	
	return 0;
}